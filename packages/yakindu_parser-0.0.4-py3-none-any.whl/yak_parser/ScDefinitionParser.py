#  Copyright (c) 2021. Paul Kogel.
#  p.kogel@tu-berlin.de
#  All rights reserved.

import logging
import re
from enum import Enum
from typing import List, Optional

from yak_parser.Statechart import Statechart, ScEventType, ScEvent

logger = logging.getLogger(__name__)


class _ParserState(Enum):
    NONE = 0
    IF_READ = 1
    IF_NAME = 2
    IF_BEGIN = 3
    EVT_TYPE = 4
    EVT_READ = 5


class ScDefinitionParser:
    """Parses a YAKINDU statechart definition section (partially)."""

    def __init__(self, sc: Statechart):
        self.sc = sc

    @staticmethod
    def _preprocess(text: str) -> str:
        """Removes comments, linebreaks, and redundant whitespace."""

        # Remove line comments:
        clean_lines: List[str] = []
        for line in text.splitlines():
            if '//' in line and ('*/' not in line or line.index('*/') < line.index('//')):
                clean_lines.append(line[0:line.index('//')])
                continue

            clean_lines.append(line)
        cleaned: str = ' '.join(clean_lines)

        # Remove multiline comments (may not work every time):
        cleaned = re.sub(re.compile(r'/\*.*\*/'), ' ', cleaned)

        # Clean whitespace:
        cleaned = re.sub(re.compile(r'\s+'), ' ', cleaned).strip()
        return cleaned

    def _parse_events(self, text: str):
        current_if: Optional[str] = None
        status: _ParserState = _ParserState.NONE

        evt_type: ScEventType = ScEventType.INPUT

        for word in text.split():
            if word == 'interface':
                status = _ParserState.IF_READ
                continue
            if word == 'interface:':  # no name
                current_if = ''
                status = _ParserState.IF_BEGIN
                continue
            if word == 'internal:':
                current_if = 'internal'
                status = _ParserState.IF_BEGIN
                continue
            if status == _ParserState.IF_READ:  # waiting for name
                current_if = word.replace(':', '')
                status = _ParserState.IF_NAME if ':' not in word else _ParserState.IF_BEGIN
                continue
            if word == 'internal':
                current_if = word
                status = _ParserState.IF_NAME
                continue
            if status == _ParserState.IF_NAME:
                if word == ':':
                    status = _ParserState.IF_BEGIN

            # Next: read event definitions
            if current_if == 'internal':  # internal definitions
                if status == _ParserState.IF_BEGIN:
                    if word == 'event':
                        evt_type = ScEventType.INTERNAL
                        status = _ParserState.EVT_READ
                        continue
                elif status == _ParserState.EVT_READ:
                    evt_name = word
                    self.sc.definition.events[current_if][evt_name] = ScEvent(current_if, evt_name, evt_type)
                    status = _ParserState.IF_BEGIN
            else:  # interfaces
                if status == _ParserState.IF_BEGIN:
                    if word == 'out':
                        evt_type = ScEventType.OUTPUT
                        status = _ParserState.EVT_TYPE
                    elif word == 'in':
                        evt_type = ScEventType.INPUT
                        status = _ParserState.EVT_TYPE
                    continue
                elif status == _ParserState.EVT_TYPE:
                    if word == 'event':
                        status = _ParserState.EVT_READ
                        continue
                elif status == _ParserState.EVT_READ:
                    evt_name = word
                    self.sc.definition.events[current_if][evt_name] = ScEvent(current_if, evt_name, evt_type)
                    status = _ParserState.IF_BEGIN
                    continue

        # Info:
        if 'internal' in self.sc.definition.events:
            logger.info('Found %d interfaces + internal definitions.' % (len(self.sc.definition.events) - 1))
        else:
            logger.info('Found %d interfaces.' % (len(self.sc.definition.events)))

    def parse(self, text: str):
        cleaned = self._preprocess(text)
        self._parse_events(cleaned)
