#  Copyright (c) 2021. Paul Kogel.
#  p.kogel@tu-berlin.de
#  All rights reserved.

import logging
import random
import string
from collections import defaultdict
from enum import Enum
from typing import List, Optional, Dict, Set

import networkx
import tabulate
from networkx import DiGraph

logger = logging.getLogger(__name__)


class NodeType(Enum):  # node in hierarchy tree
    ROOT = 0,  # root node
    REGION = 1,
    STATE = 2,
    FINAL = 3,
    CHOICE = 4


class ScHistoryType(Enum):
    NONE = 0
    SHALLOW = 1
    DEEP = 2


class ScSpecification:
    """Transition specification"""

    def __init__(self):
        self.triggers: Set[str] = set()
        self.effects: Set[str] = set()
        self.guard: Optional[str] = None

    def __str__(self):
        elements: List[str] = []
        trigger_list: List[str] = list(self.triggers)
        effect_list: List[str] = list(self.effects)
        trigger_list.sort()
        effect_list.sort()

        if len(trigger_list) > 0:
            elements.append(','.join(trigger_list))
        if self.guard is not None:
            elements.append('[%s]' % self.guard)
        if len(effect_list) > 0:
            elements.append('/ ' + ';'.join(effect_list))
        return ' '.join(elements)

    def __hash__(self):
        return hash(self.__str__())

    def __eq__(self, other):
        return str(self) == str(other)


class ScTransition:
    def __init__(self, transition_id: str, source_id: str, target_id: str, specification: ScSpecification):
        self.transition_id = transition_id
        self.source_id = source_id
        self.target_id = target_id
        self.specification: ScSpecification = specification

    def __str__(self):
        return '%s: %s -> %s : %s' % (self.transition_id, self.source_id, self.target_id, self.specification)

    def __hash__(self):
        return hash(self.__str__())

    def __eq__(self, other):
        return str(self) == str(other)


class ScState:
    """Statechart state"""

    def __init__(self, state_id: str, name: str, initial: bool = False):
        self.state_id = state_id
        self.name = name
        self.initial = initial  # initial state?

        self.specifications: List[ScSpecification] = []  # specifications


class ScChoice:
    """Statechart state"""

    def __init__(self, choice_id: str):
        self.choice_id = choice_id


class ScFinalState:
    """Statechart final state"""

    def __init__(self, state_id: str):
        self.state_id = state_id


class ScRegion:
    """Statechart region. Initial state information is stored with corresponding child."""

    def __init__(self, region_id: str, name: str, history: ScHistoryType = ScHistoryType.NONE):
        self.state_id = region_id
        self.name = name
        self.history = history


class ScEventType(Enum):
    INPUT = 1
    OUTPUT = 2
    INTERNAL = 3


class ScEvent:
    """Statechart event definition"""

    def __init__(self, interface: str, name: str, e_type: ScEventType):
        self.interface = interface
        self.e_type = e_type
        self.name = name

    def __str__(self):
        t_str: str = 'in ' if self.e_type == ScEventType.INPUT \
            else 'out ' if self.e_type == ScEventType.OUTPUT else ''
        e_name: str = self.name if self.interface == '' or self.interface == 'internal' \
            else self.interface + '.' + self.name
        return t_str + e_name

    def __hash__(self):
        return hash(self.__str__())
    def __eq__(self, other):
        return str(self) == str(other)


class ScDefinition:
    """Statechart definition"""

    def __init__(self):
        self.events: Dict[str, Dict[str, ScEvent]] = defaultdict(dict)  # interface/internal -> (name -> event)


class Statechart:
    def __init__(self):
        self.transitions: Dict[str, List[ScTransition]] = defaultdict(list)  # source state -> outgoing edges
        self.hierarchy: DiGraph = DiGraph()  # state hierarchy
        self.definition: ScDefinition = ScDefinition()

    def get_event(self, interface: str, name: str) -> ScEvent:
        """Return event with provided name."""
        return self.definition.events[interface][name]

    def get_name(self, id_) -> str:
        """Get name of object with provided id."""
        if self.hierarchy.nodes[id_]['ntype'] == NodeType.FINAL:
            return 'Final'
        elif self.hierarchy.nodes[id_]['ntype'] == NodeType.CHOICE:
            return 'Choice'
        else:
            return self.hierarchy.nodes[id_]['obj'].name

    def random_node_id(self) -> str:
        """Returns a random 22 char string with _ prefix, containing: letters, _, -, digits.
        The id is unique, i.e., not used by any region or state."""
        while True:
            rand_id = '_' + ''.join(random.choices(string.ascii_lowercase + string.digits + '_' + '-', k=22))
            if rand_id not in self.hierarchy.nodes:
                return rand_id

    def print_transitions(self):
        """Prints all transitions to stdout"""

        transitions: List[List[str]] = []
        for source in self.transitions:
            for transition in self.transitions[source]:
                transitions.append(['%s' % (self.get_name(transition.source_id)),
                                    '%s' % (self.get_name(transition.target_id)),
                                    transition.specification])

        # Find initial state:
        initial_state: str = [n for n in self.hierarchy if self.hierarchy.nodes[n]['ntype'] == NodeType.STATE and
                              self.hierarchy.nodes[n]['obj'].initial][0]

        print()
        print('%d transitions, %d states.' % (len(transitions),
                                              len([n for n in self.hierarchy.nodes if
                                                   self.hierarchy.nodes[n]['ntype'] == NodeType.STATE])))
        print('Initial state: "%s"' % (self.get_name(initial_state)))
        print(tabulate.tabulate(transitions, headers=['Source', 'Target', 'Specification']))

    def save_hierarchy_image(self, name: str):
        """Saves an svg image of the statechart hierarchy."""

        pgraph = networkx.drawing.nx_pydot.to_pydot(self.hierarchy)

        for node in pgraph.get_nodes():
            node_name = node.get_name().strip('"')  # strip quotes
            if self.hierarchy.nodes[node_name]['ntype'] == NodeType.STATE and \
                    self.hierarchy.nodes[node_name]['obj'].initial:
                node.set('color', 'red')
                continue
            if self.hierarchy.nodes[node_name]['ntype'] == NodeType.REGION:
                if self.hierarchy.nodes[node_name]['obj'].history == ScHistoryType.DEEP:
                    node.set('color', 'blue')
                elif self.hierarchy.nodes[node_name]['obj'].history == ScHistoryType.SHALLOW:
                    node.set('color', 'lightblue')

        with open(name, 'w') as dfile:
            dfile.write(pgraph.create_svg().decode("utf-8"))
