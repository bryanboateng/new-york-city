#  Copyright (c) 2021. Paul Kogel.
#  p.kogel@tu-berlin.de
#  All rights reserved.

import logging
import random

from yak_parser.Statechart import Statechart
from yak_parser.StatechartParser import StatechartParser


def run():
    """Demonstrates statechart parsing"""

    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    random.seed(100)  # for random id generator
    sc: Statechart = StatechartParser().parse(path='Original Statechart.ysc')
    sc.save_hierarchy_image('hierarchy.svg')
    sc.print_transitions()


if __name__ == '__main__':
    run()
