#  Copyright (c) 2021. Paul Kogel.
#  p.kogel@tu-berlin.de
#  All rights reserved.

import logging
import re
import xml.etree.ElementTree as ET
from typing import Dict, Optional

from yak_parser.Statechart import ScSpecification, Statechart, ScState, NodeType, ScTransition, ScHistoryType, ScRegion, \
    ScFinalState, ScChoice
from yak_parser.ScDefinitionParser import ScDefinitionParser

logger = logging.getLogger(__name__)


class StatechartParser:
    """Parses YAKINDU statechart XML"""

    def __init__(self):
        self.spec_pattern = re.compile(r'([^\[\]/]*)\s*(\[[^\[\]/]+])?\s*(/[^\[\]/]+)?')  # trigger [guard] / effect
        self.namespaces: Dict[str, str] = {'sgraph': 'http://www.yakindu.org/sct/sgraph/2.0.0',
                                           'xmi': 'http://www.omg.org/XMI',
                                           'xsi': 'http://www.w3.org/2001/XMLSchema-instance'}

    def parse_specification(self, spec: str) -> ScSpecification:
        """Parses a Yakindu state/transition specification."""

        if len(spec.strip()) == 0:
            return ScSpecification()  # empty

        match = self.spec_pattern.match(spec.strip())
        assert match is not None, 'Could not parse specification "%s": regex does not match.' % spec

        # Get components:
        triggers: Optional[str] = match.group(1) if len(match.group(1)) > 0 else None
        guard: Optional[str] = match.group(2)
        effects: Optional[str] = match.group(3)

        spec: ScSpecification = ScSpecification()
        if guard is not None:
            spec.guard = guard[1:-1]  # remove enclosing brackets

        if triggers is not None:
            for trigger in triggers.split(','):
                spec.triggers.add(trigger.strip())

        if effects is not None:
            for effect in effects[1:].split(';'):  # without leading slash
                spec.effects.add(effect.strip())

        return spec

    def parse_state_vertex(self, vertex: ET.Element, parent_region: str, sc: Statechart) -> ScState:
        """Parses a state vertex. States contain either one/multiple regions, outgoing edges, or nothing.
        Also, they may have a specification."""
        state_name: str = vertex.attrib['name']
        state_id: str = vertex.attrib['{%s}id' % self.namespaces['xmi']]

        # Add spec, if present:
        state: ScState = ScState(state_id=state_id, name=state_name)
        if 'specification' in vertex.attrib:
            # Parse multiple specifications:
            for spec in vertex.attrib['specification'].split('\r\n'):
                state.specifications.append(self.parse_specification(spec))

        # Insert into hierarchy:
        sc.hierarchy.add_node(state_id, label=state_name, obj=state, ntype=NodeType.STATE)
        sc.hierarchy.add_edge(parent_region, state_id)

        for region in vertex.findall('regions'):
            self.parse_region(region, state_id, sc)
        for edge in vertex.findall('outgoingTransitions'):
            sc.transitions[state_id].append(self.parse_transition(edge, state_id))

        return state

    def parse_choice_vertex(self, vertex: ET.Element, parent_region: str, sc: Statechart) -> ScChoice:
        """Parses a choice vertex."""
        choice_id: str = vertex.attrib['{%s}id' % self.namespaces['xmi']]

        # Add spec, if present:
        choice: ScChoice = ScChoice(choice_id=choice_id)

        # Insert into hierarchy:
        sc.hierarchy.add_node(choice_id, label='Choice', obj=choice, ntype=NodeType.CHOICE, shape='diamond')
        sc.hierarchy.add_edge(parent_region, choice_id)

        for edge in vertex.findall('outgoingTransitions'):
            sc.transitions[choice_id].append(self.parse_transition(edge, choice_id))

        return choice

    def parse_final_state_vertex(self, vertex: ET.Element, parent_region: str, sc: Statechart) -> ScFinalState:
        """Parses a final state vertex."""
        state_id: str = vertex.attrib['{%s}id' % self.namespaces['xmi']]

        # Add spec, if present:
        state: ScFinalState = ScFinalState(state_id=state_id)

        # Insert into hierarchy:
        sc.hierarchy.add_node(state_id, label='Final', obj=state, ntype=NodeType.FINAL, peripheries=2)
        sc.hierarchy.add_edge(parent_region, state_id)

        return state

    def parse_transition(self, transition: ET.Element, source_id: str) -> ScTransition:
        """Parses a transition. Extracts its target and specification."""
        trans_id: str = transition.attrib['{%s}id' % self.namespaces['xmi']]
        trans_target: str = transition.attrib['target']
        trans_spec: str = transition.attrib['specification'] if 'specification' in transition.attrib else ''

        return ScTransition(transition_id=trans_id, source_id=source_id, target_id=trans_target,
                            specification=self.parse_specification(trans_spec))

    def parse_region(self, region: ET.Element, parent_region: str, sc: Statechart):
        """Parses a region. A region may contain vertices, but no other regions. Also, it has a name."""

        # Create region + add to hierarchy:
        region_name: Optional[str] = region.get('name')
        region_id: str = region.attrib['{%s}id' % self.namespaces['xmi']]
        region_obj: ScRegion = ScRegion(region_name, region_id)
        sc.hierarchy.add_node(region_id, label=region_name, ntype=NodeType.REGION, obj=region_obj, shape='box')
        sc.hierarchy.add_edge(parent_region, region_id)

        # First, find initial state:
        initial_id: Optional[str] = None
        for vertex in region.findall('vertices'):
            vertex_type: str = vertex.attrib['{%s}type' % self.namespaces['xsi']]
            if vertex_type != 'sgraph:Entry':
                continue

            # Determine history settings:
            region_obj.history = ScHistoryType.NONE
            if 'kind' in vertex.attrib:
                vertex_kind: str = vertex.attrib['kind']
                if vertex_kind == 'DEEP_HISTORY':
                    region_obj.history = ScHistoryType.DEEP
                elif vertex_kind == 'SHALLOW_HISTORY':
                    region_obj.history = ScHistoryType.SHALLOW
                else:
                    raise ValueError(
                        'Region "%s" contains entry of unsupported kind "%s".' % (region_name, vertex_kind))

            # Find successor:
            outgoing: ET.Element = vertex.find('outgoingTransitions')
            assert outgoing is not None, 'Region "%s" contains entry vertex without outgoing transition!' % region_name

            transition: ScTransition = self.parse_transition(outgoing, '')
            initial_id = transition.target_id
            break

        # assert initial_id is not None, 'Region "%s" has no entry.' % region_name

        # Next, parse other vertices:
        for vertex in region.findall('vertices'):
            vertex_type: str = vertex.attrib['{%s}type' % self.namespaces['xsi']]
            if vertex_type == 'sgraph:Entry':
                continue
            elif vertex_type == 'sgraph:State':
                new_state: ScState = self.parse_state_vertex(vertex, region_id, sc)
                if new_state.state_id == initial_id:
                    new_state.initial = True  # flag initial state
            elif vertex_type == 'sgraph:FinalState':
                self.parse_final_state_vertex(vertex, region_id, sc)
            else:
                raise ValueError('Region "%s" contains vertex of unsupported type "%s".' % (region_name, vertex_type))

    def parse(self, path: str):
        tree = ET.parse(path)
        root = tree.getroot()

        sc_root: ET.Element = root.find('sgraph:Statechart', self.namespaces)
        assert sc_root is not None, 'No statechart element found!'

        sc_doc: Statechart = Statechart()
        sc_doc.hierarchy.add_node('root', ntype=NodeType.ROOT)
        for region in sc_root.findall('regions'):
            self.parse_region(region, 'root', sc_doc)

        # Parse definition section:
        ScDefinitionParser(sc_doc).parse(sc_root.get('specification'))

        logger.info('Document parsed: %d regions, %d states.' % (
            len([n for n in sc_doc.hierarchy.nodes if sc_doc.hierarchy.nodes[n]['ntype'] == NodeType.REGION]),
            len([n for n in sc_doc.hierarchy.nodes if sc_doc.hierarchy.nodes[n]['ntype'] == NodeType.STATE])
        ))
        return sc_doc
